import IconUser from "assets/IconUser";

export default function InputLogin(props: InputLoginProps) {
  return (
    <div
      className="w-56 absolute inline-flex flex-col items-start text-left font-normal h-[68px] left-[calc(50%_-_112px_+_151px)] top-[calc(50%_-_34px_+_-30px)]"
    >
      <p
        className={`w-full text-xs leading-normal m-0 font-['Roboto'] text-[rgba(143,227,207,1)]`}
      >
        Usuario
      </p>
      <div
        className={`py-3 relative flex items-center text-black w-[204px] h-[25px] pl-[13px] bg-[rgba(143,227,207,1)] overflow-clip gap-[-18px] font-['Inter']`}
      >
        <p className="opacity-50 leading-6 m-0 w-[116px] text-[9px]">
          ingrese su usuario
        </p>
        <IconUser />
      </div>
    </div>
  );
}

InputLogin.defaultProps = {};

interface InputLoginProps {}

/**
 * This component was generated from Figma with FireJet.
 * Learn more at https://www.firejet.io
 *
 * README:
 * The output code may look slightly different when copied to your codebase. To fix this:
 * 1. Include the necessary fonts. The required fonts are imported from public/index.html
 * 2. Include the global styles. They can be found in App.css
 *
 * Note: Step 2 is not required for tailwind.css output
 */
