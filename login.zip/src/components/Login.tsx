import Line1 from "assets/Line1";
import InputLogin from "components/InputLogin";
import IconEye from "assets/IconEye";
import Group from "assets/Group";
import IconFacebookRound from "assets/IconFacebookRound";
import IconTwitterRound from "assets/IconTwitterRound";

export default function Login(props: LoginProps) {
  return (
    <div
      className="relative w-[566px] h-[388px] drop-shadow-lg bg-gradient-to-b from-[rgba(134,142,152,1)] to-[rgba(63,68,74,1)] overflow-clip"
      style={props.style}
    >
      <Line1 />
      <div
        className="[background:url(https://uortjlczjmucmpaqqhqm.supabase.co/storage/v1/object/public/firejet-converted-images/images/4e65134da83c87e0d94c80f90f11db14b261035b.webp)_no-repeat_center_/_contain] left-10 absolute w-[204px] h-[91px] top-[132px]"
       />
      <InputLogin />
      <div
        className={`px-4 pb-0.5 absolute bg-black inline-flex justify-center items-center text-left font-bold w-[95px] h-[19px] left-[379px] top-[274px] overflow-clip rounded-[5px] font-['Inter'] text-[rgba(121,249,226,1)]`}
      >
        <p className="m-0 text-[8px] leading-[normal]">Ingresar</p>
      </div>
      <p
        className={`absolute font-bold text-center text-black inline m-0 h-[35px] w-[206px] left-[317px] top-[78px] font-['Roboto'] text-[22px] tracking-[1.28px] leading-[1.64]`}
      >
        Bienvenido
      </p>
      <div
        className="h-0 absolute w-[195px] left-[322px] top-[118px] outline outline-1 outline-[rgba(143,227,207,1)]"
       />
      <div
        className="absolute gap-2 inline-flex flex-col items-start text-left font-normal w-[238px] h-[68px] left-[calc(50%_-_119px_+_158px)] top-[calc(50%_-_34px_+_24px)]"
      >
        <p
          className={`w-full text-xs leading-normal m-0 font-['Roboto'] text-[rgba(143,227,207,1)]`}
        >
          Contraseña
        </p>
        <div
          className={`pt-3 pb-2.5 pl-4 relative gap-2 flex items-center text-black w-[203px] h-[25px] pr-[23px] bg-[rgba(143,227,207,1)] overflow-clip font-['Inter']`}
        >
          <div>
            <p className="opacity-50 leading-6 m-0 h-6 w-[116px] text-[9px]">
              ingrese su contraseña
            </p>
          </div>
          <IconEye />
        </div>
      </div>
      <p
        className={`absolute font-bold text-left inline m-0 h-[15px] w-[140px] left-[335px] top-[245px] font-['Roboto'] text-[8px] leading-[normal] text-[rgba(57,50,50,1)]`}
      >
        Recuperar contraseña
      </p>
      <Group />
      <IconFacebookRound />
      <IconTwitterRound />
    </div>
  );
}

Login.defaultProps = {
  style: {},
};

interface LoginProps {
  style: Object;
}

/**
 * This component was generated from Figma with FireJet.
 * Learn more at https://www.firejet.io
 *
 * README:
 * The output code may look slightly different when copied to your codebase. To fix this:
 * 1. Include the necessary fonts. The required fonts are imported from public/index.html
 * 2. Include the global styles. They can be found in App.css
 *
 * Note: Step 2 is not required for tailwind.css output
 */
