import React from "react";
import Login from "./components/Login";
import "./App.css";

function App() {
  return <Login />;
}

export default App;
