export default function IconEye(props: IconEyeProps) {
  return (
    <div className="w-full">
      <div
        className="absolute w-[21px] left-[86.33%] right-[3.33%] top-[21%] bottom-[19%]"
      >
        <svg
          width="100%"
          height="100%"
          preserveAspectRatio="none"
          viewBox="0 0 21 15"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M 1 7.5 C 1 7.5 4.455 1 10.5 1 C 16.546 1 20 7.5 20 7.5 C 20 7.5 16.546 14 10.5 14 C 4.455 14 1 7.5 1 7.5 Z"
            stroke="black"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
           />
          <path
            d="M 10.734 9.974 C 12.121 9.974 13.245 8.866 13.245 7.5 C 13.245 6.134 12.121 5.026 10.734 5.026 C 9.347 5.026 8.223 6.134 8.223 7.5 C 8.223 8.866 9.347 9.974 10.734 9.974 Z"
            stroke="black"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
           />
        </svg>
      </div>
    </div>
  );
}

IconEye.defaultProps = {};

interface IconEyeProps {}

/**
 * This component was generated from Figma with FireJet.
 * Learn more at https://www.firejet.io
 *
 * README:
 * The output code may look slightly different when copied to your codebase. To fix this:
 * 1. Include the necessary fonts. The required fonts are imported from public/index.html
 * 2. Include the global styles. They can be found in App.css
 *
 * Note: Step 2 is not required for tailwind.css output
 */
