export default function Line1(props: Line1Props) {
  return (
    <div
      className="w-1 absolute flex h-[333px] left-[273.5px] top-[28.5px] drop-shadow-lg"
    >
      <svg
        width="100%"
        height="100%"
        preserveAspectRatio="none"
        viewBox="0 0 4 333"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g filter="url(#filter0_i_12_2)">
          <path
            d="M 2 2 L 2 331"
            stroke="#9CFFFC"
            strokeWidth="3"
            strokeLinecap="round"
           />
        </g>
        <defs>
          <filter
            id="filter0_i_12_2"
            x="0.5"
            y="0.5"
            width="3"
            height="336"
            filterUnits="userSpaceOnUse"
            colorInterpolationFilters="sRGB"
          >
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="BackgroundImageFix"
              result="shape"
             />
            <feColorMatrix
              in="SourceAlpha"
              type="matrix"
              values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
              result="hardAlpha"
             />
            <feOffset dy="4" />
            <feGaussianBlur stdDeviation="2" />
            <feComposite
              in2="hardAlpha"
              operator="arithmetic"
              k2="-1"
              k3="1"
             />
            <feColorMatrix
              type="matrix"
              values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"
             />
            <feBlend
              mode="normal"
              in2="shape"
              result="effect1_innerShadow_12_2"
             />
          </filter>
        </defs>
      </svg>
    </div>
  );
}

Line1.defaultProps = {};

interface Line1Props {}

/**
 * This component was generated from Figma with FireJet.
 * Learn more at https://www.firejet.io
 *
 * README:
 * The output code may look slightly different when copied to your codebase. To fix this:
 * 1. Include the necessary fonts. The required fonts are imported from public/index.html
 * 2. Include the global styles. They can be found in App.css
 *
 * Note: Step 2 is not required for tailwind.css output
 */
