export default function IconTwitterRound(props: IconTwitterRoundProps) {
  return (
    <div className="absolute w-[38px] h-[38px] left-[195px] top-[270px]">
      <svg
        width="100%"
        height="100%"
        preserveAspectRatio="none"
        viewBox="0 0 38 38"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M 18.934 37.869 C 29.391 37.869 37.869 29.391 37.869 18.934 C 37.869 8.477 29.391 0 18.934 0 C 8.477 0 0 8.477 0 18.934 C 0 29.391 8.477 37.869 18.934 37.869 Z"
          fill="#5EA7FF"
         />
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M 27.465 13.82 C 27.465 13.82 29.034 13.697 29.664 13.228 C 29.664 13.228 29.513 13.768 27.624 15.474 C 27.624 15.474 28.26 24.682 18.572 26.937 C 18.572 26.937 13.659 27.983 10.098 25.314 C 10.098 25.314 13.825 25.975 15.922 23.663 C 15.922 23.663 13.217 23.691 12.362 20.94 C 12.362 20.94 13.383 21.16 13.99 20.885 C 13.99 20.885 10.926 20.251 10.982 16.922 C 10.982 16.922 11.81 17.528 12.555 17.418 C 12.555 17.418 9.795 15.078 11.506 12.162 C 11.506 12.162 15.204 16.521 19.787 16.262 C 19.707 15.95 19.664 15.624 19.664 15.286 C 19.664 13.118 21.427 11.361 23.602 11.361 C 24.701 11.361 25.695 11.81 26.41 12.533 C 26.934 12.542 28.011 12.449 29.087 11.681 C 29.087 11.681 29.149 12.521 27.465 13.82 Z"
          fill="white"
         />
      </svg>
    </div>
  );
}

IconTwitterRound.defaultProps = {};

interface IconTwitterRoundProps {}

/**
 * This component was generated from Figma with FireJet.
 * Learn more at https://www.firejet.io
 *
 * README:
 * The output code may look slightly different when copied to your codebase. To fix this:
 * 1. Include the necessary fonts. The required fonts are imported from public/index.html
 * 2. Include the global styles. They can be found in App.css
 *
 * Note: Step 2 is not required for tailwind.css output
 */
