export default function Group(props: GroupProps) {
  return (
    <div
      className="absolute left-[8.83%] right-[84.45%] top-[69.59%] bottom-[20.62%]"
    >
      <svg
        width="100%"
        height="100%"
        preserveAspectRatio="none"
        viewBox="0 0 38 38"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M 18.934 37.869 C 29.391 37.869 37.869 29.391 37.869 18.934 C 37.869 8.477 29.391 0 18.934 0 C 8.477 0 0 8.477 0 18.934 C 0 29.391 8.477 37.869 18.934 37.869 Z"
          fill="#FF78C7"
         />
        <path
          d="M 11.992 12.943 V 24.926 C 11.992 25.452 12.417 25.877 12.943 25.877 H 24.926 C 25.452 25.877 25.877 25.452 25.877 24.926 V 12.943 C 25.877 12.417 25.452 11.992 24.926 11.992 H 12.943 C 12.417 11.992 11.992 12.417 11.992 12.943 Z M 9.467 12.943 C 9.467 11.023 11.022 9.467 12.943 9.467 H 24.926 C 26.846 9.467 28.401 11.022 28.401 12.943 V 24.926 C 28.401 26.846 26.846 28.401 24.926 28.401 H 12.943 C 11.023 28.401 9.467 26.846 9.467 24.926 V 12.943 Z"
          fill="white"
         />
        <path
          d="M 19.25 23.352 C 16.984 23.352 15.147 21.516 15.147 19.25 C 15.147 16.984 16.984 15.147 19.25 15.147 C 21.516 15.147 23.352 16.984 23.352 19.25 C 23.352 21.516 21.516 23.352 19.25 23.352 Z M 19.25 20.828 C 20.121 20.828 20.828 20.121 20.828 19.25 C 20.828 18.378 20.121 17.672 19.25 17.672 C 18.378 17.672 17.672 18.378 17.672 19.25 C 17.672 20.121 18.378 20.828 19.25 20.828 Z"
          fill="white"
         />
        <path
          d="M 23.668 15.147 C 24.191 15.147 24.615 14.724 24.615 14.201 C 24.615 13.678 24.191 13.254 23.668 13.254 C 23.145 13.254 22.721 13.678 22.721 14.201 C 22.721 14.724 23.145 15.147 23.668 15.147 Z"
          fill="white"
         />
      </svg>
    </div>
  );
}

Group.defaultProps = {};

interface GroupProps {}

/**
 * This component was generated from Figma with FireJet.
 * Learn more at https://www.firejet.io
 *
 * README:
 * The output code may look slightly different when copied to your codebase. To fix this:
 * 1. Include the necessary fonts. The required fonts are imported from public/index.html
 * 2. Include the global styles. They can be found in App.css
 *
 * Note: Step 2 is not required for tailwind.css output
 */
