export default function IconUser(props: IconUserProps) {
  return (
    <div
      className="absolute w-[15px] left-[87.5%] right-[5.15%] top-[19.88%] bottom-[24.13%]"
    >
      <svg
        width="100%"
        height="100%"
        preserveAspectRatio="none"
        viewBox="0 0 15 14"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <mask
          id="path-1-outside-1_117_5"
          maskUnits="userSpaceOnUse"
          x="0"
          y="6.56603"
          width="15"
          height="8"
          fill="black"
        >
          <rect fill="white" y="6.56603" width="15" height="8" />
          <path
            d="M 13 12.138 V 10.948 C 13 10.316 12.71 9.71 12.195 9.264 C 11.679 8.817 10.979 8.566 10.25 8.566 H 4.75 C 4.021 8.566 3.321 8.817 2.805 9.264 C 2.29 9.71 2 10.316 2 10.948 V 12.138"
           />
        </mask>
        <path
          d="M 11.5 12.138 C 11.5 12.967 12.172 13.638 13 13.638 C 13.828 13.638 14.5 12.967 14.5 12.138 H 11.5 Z M 10.25 8.566 V 7.066 V 8.566 Z M 4.75 8.566 V 7.066 V 8.566 Z M 2 10.948 H 0.5 H 2 Z M 0.5 12.138 C 0.5 12.967 1.172 13.638 2 13.638 C 2.828 13.638 3.5 12.967 3.5 12.138 H 0.5 Z M 14.5 12.138 V 10.948 H 11.5 V 12.138 H 14.5 Z M 14.5 10.948 C 14.5 9.843 13.991 8.835 13.177 8.13 L 11.213 10.398 C 11.429 10.585 11.5 10.789 11.5 10.948 H 14.5 Z M 13.177 8.13 C 12.368 7.43 11.313 7.066 10.25 7.066 V 10.066 C 10.646 10.066 10.989 10.204 11.213 10.398 L 13.177 8.13 Z M 10.25 7.066 H 4.75 V 10.066 H 10.25 V 7.066 Z M 4.75 7.066 C 3.687 7.066 2.632 7.43 1.824 8.13 L 3.787 10.398 C 4.011 10.204 4.354 10.066 4.75 10.066 V 7.066 Z M 1.824 8.13 C 1.009 8.835 0.5 9.843 0.5 10.948 H 3.5 C 3.5 10.789 3.571 10.585 3.787 10.398 L 1.824 8.13 Z M 0.5 10.948 V 12.138 H 3.5 V 10.948 H 0.5 Z"
          fill="black"
          mask="url(#path-1-outside-1_117_5)"
         />
        <path
          d="M 7.431 7.982 C 9.259 7.982 10.931 6.677 10.931 4.85 C 10.931 3.023 9.259 1.719 7.431 1.719 C 5.603 1.719 3.931 3.023 3.931 4.85 C 3.931 6.677 5.603 7.982 7.431 7.982 Z"
          stroke="black"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
         />
      </svg>
    </div>
  );
}

IconUser.defaultProps = {};

interface IconUserProps {}

/**
 * This component was generated from Figma with FireJet.
 * Learn more at https://www.firejet.io
 *
 * README:
 * The output code may look slightly different when copied to your codebase. To fix this:
 * 1. Include the necessary fonts. The required fonts are imported from public/index.html
 * 2. Include the global styles. They can be found in App.css
 *
 * Note: Step 2 is not required for tailwind.css output
 */
