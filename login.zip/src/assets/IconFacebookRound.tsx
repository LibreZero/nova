export default function IconFacebookRound(props: IconFacebookRoundProps) {
  return (
    <div className="absolute w-[38px] h-[38px] left-[123px] top-[270px]">
      <svg
        width="100%"
        height="100%"
        preserveAspectRatio="none"
        viewBox="0 0 38 38"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M 18.934 37.869 C 29.391 37.869 37.869 29.391 37.869 18.934 C 37.869 8.477 29.391 0 18.934 0 C 8.477 0 0 8.477 0 18.934 C 0 29.391 8.477 37.869 18.934 37.869 Z"
          fill="#5B68C0"
         />
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M 21.484 10.732 C 21.484 10.732 18.674 10.549 17.953 13.222 C 17.953 13.222 17.692 13.923 17.728 15.651 L 15.147 15.658 V 17.918 L 17.728 17.911 V 27.139 H 21.018 V 17.918 L 23.626 17.918 V 15.651 L 21.018 15.651 V 14.419 C 21.018 13.621 21.461 12.857 22.758 12.857 H 23.983 V 10.732 H 21.484 Z"
          fill="white"
         />
      </svg>
    </div>
  );
}

IconFacebookRound.defaultProps = {};

interface IconFacebookRoundProps {}

/**
 * This component was generated from Figma with FireJet.
 * Learn more at https://www.firejet.io
 *
 * README:
 * The output code may look slightly different when copied to your codebase. To fix this:
 * 1. Include the necessary fonts. The required fonts are imported from public/index.html
 * 2. Include the global styles. They can be found in App.css
 *
 * Note: Step 2 is not required for tailwind.css output
 */
